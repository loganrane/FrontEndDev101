# Landing Page Project

## Table of Contents

-   [Instructions](#instructions)

## Instructions

Download the project and use launch the index.html to use it.
The project is based on a landing page with main features that we can jump to any location in the page by using the
`navbar` buttons. Also smooth scroll effects is added to provide good user interface.
The section in which you'll be active will have some animations.
